import random
a=random.randint(1,100)
b=random.randint(1,100)
c=random.randint(1,100)
if a<(b+c) and b<(a+c) and c<(a+b):
  print('Si a =',a,', b =',b,'y c =',c,' entonces si se puede hacer un triangulo')
  if a==b==c:
    print('Equilatero')
  elif a==b or b==c or a==c:
    print('Isósceles')
  else:
    print('Escaleno')
else:
  print('Si a =',a,', b =',b,'y c =',c,' entonces no se puede hacer un triangulo')