num1=int(input("Ingrese N°1: "))
num2=int(input("Ingrese N°2: "))
if num1>0 and num2>0:
    resultado=num1+num2
    print(f"{num2} + {num1} = {resultado}")
else:
    print("los numeros deben ser positivos")