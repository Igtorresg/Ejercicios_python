def main():
    print("par o impar")
    num1=int(input("Escriba un numero entero: "))
    num2=int(input("Escriba un numero entero: "))
    num3=int(input("Escriba un numero entero: "))
    if num1>0 and num2>0 and num3>0:
        if 