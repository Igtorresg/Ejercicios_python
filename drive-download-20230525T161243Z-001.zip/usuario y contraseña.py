class user:
    def __init__(self, nom, pwd):
        self.nom=nom
        self.pwd=pwd
        
u1 = user("pedro" , "1234")
u2 = user("angel" , "a4s1")

usuarios = (u1, u2)

n = input("Ingrese su usuario: ")
p = input("Ingrese su contraseña: ")

k=0

for i in range(len(usuarios)):
    if usuarios[i].nom == n and usuarios[i].pwd == p:
        print(usuarios[i].nom, " Bienvenid@ al programa")
        k=1
        break
    
if k==0:
    print("Intente nuevamente!")
    
